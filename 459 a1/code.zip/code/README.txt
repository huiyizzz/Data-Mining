The file "extract.py" extracts tweets to form data sets D1 and D2.
The file "report.py" calculates frequent tokens and create the cloud words.

All this code is modified based on provided code by TA.